package org.example;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class log4jejercicio3 {


    private static final Logger logger = LogManager.getLogger(log4jejercicio3.class);


    public static int sumaElementos(int[][] mat) {
        int suma = 0;
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                suma += mat[i][j];
            }
        }
        return suma;
    }


    public static void main(String[] args) {

        int[][] mat1 = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        int[][] mat2 = {{10, 20}, {30, 40}};


        int sumaMat1 = sumaElementos(mat1);
        int sumaMat2 = sumaElementos(mat2);


        logger.info("Suma de mat1: " + sumaMat1);
        logger.info("Suma de mat2: " + sumaMat2);

    }
}
