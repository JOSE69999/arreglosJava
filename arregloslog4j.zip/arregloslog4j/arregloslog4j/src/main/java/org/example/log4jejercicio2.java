package org.example;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Arrays;

public class log4jejercicio2 {

    // mensajes
    private static final Logger logger = LogManager.getLogger(log4jejercicio2.class);


    public static int[][] diagonalSort(int[][] mat) {
        int m = mat.length;  // filas
        int n = mat[0].length;  // columnas


        for (int columna = 0; columna < n; columna++) {
            ordenarDiagonal(mat, 0, columna);
        }


        for (int fila = 1; fila < m; fila++) {
            ordenarDiagonal(mat, fila, 0);
        }

        return mat;  //matriz
    }


    private static void ordenarDiagonal(int[][] mat, int iniciarFila, int iniciarColumna) {
        int m = mat.length;  // filas
        int n = mat[0].length;  // columnas

        // diagonal
        int i = iniciarFila, j = iniciarColumna;
        int[] diagonal = new int[Math.min(m - i, n - j)];
        int index = 0;


        while (i < m && j < n) {
            diagonal[index++] = mat[i][j];
            i++;
            j++;
        }


        Arrays.sort(diagonal);


        i = iniciarFila;
        j = iniciarColumna;
        index = 0;
        while (i < m && j < n) {
            mat[i][j] = diagonal[index++];
            i++;
            j++;
        }


        logger.info("Diagonal ordenada comenzando en (" + iniciarFila + ", " + iniciarColumna + "): " + Arrays.toString(diagonal));
    }


    public static void imprimirMatriz(int[][] mat) {
        for (int[] fila : mat) {
            logger.info(Arrays.toString(fila));
        }
    }


    public static void main(String[] args) {

        int[][] mat1 = {{3, 3, 1, 1}, {2, 2, 1, 2}, {1, 1, 1, 2}};
        int[][] mat2 = {{11, 25, 66, 1, 69, 7}, {23, 55, 17, 45, 15, 52}, {75, 31, 36, 44, 58, 8},
                {22, 27, 33, 25, 68, 4}, {84, 28, 14, 11, 5, 50}};


        int[][] result1 = diagonalSort(mat1);
        int[][] result2 = diagonalSort(mat2);


        logger.info("Resultado 1 (Matriz con diagonales ordenadas):");
        imprimirMatriz(result1);

        logger.info("\nResultado 2 (Matriz con diagonales ordenadas):");
        imprimirMatriz(result2);
    }
}