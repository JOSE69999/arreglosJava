package org.example;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Main {

    private static final Logger logger = LogManager.getLogger(Main.class);

    public static int riquezaMaxima(int[][] cuentas) {
        int maxRiqueza = 0;

        for (int[] cuenta : cuentas) {
            int riqueza = 0;


            for (int saldo : cuenta) {
                riqueza += saldo;
            }


            if (riqueza > maxRiqueza) {
                maxRiqueza = riqueza;
            }
        }

        return maxRiqueza;
    }

    public static void main(String[] args) {


        int[][] cuentas1 = {{1, 2, 3}, {3, 2, 1}};

        int[][] cuentas2 = {{1, 5}, {7, 3}, {3, 5}};

        int[][] cuentas3 = {{2, 8, 7}, {7, 1, 3}, {1, 9, 5}};


        int resultado1 = riquezaMaxima(cuentas1);
        int resultado2 = riquezaMaxima(cuentas2);
        int resultado3 = riquezaMaxima(cuentas3);


        System.out.println("Ejemplo 1 - Riqueza máxima: " + resultado1);  // Salida esperada: 6
        System.out.println("Ejemplo 2 - Riqueza máxima: " + resultado2);  // Salida esperada: 10
        System.out.println("Ejemplo 3 - Riqueza máxima: " + resultado3);  // Salida esperada: 17


        logger.info("Ejemplo 1 - Riqueza máxima: " + resultado1);
        logger.info("Ejemplo 2 - Riqueza máxima: " + resultado2);
        logger.info("Ejemplo 3 - Riqueza máxima: " + resultado3);
    }
}