
package arreglos;


public class Arreglos {

    public static int encontrarRiquezaMaxima(int[][] cuentas) {
        int max = 0; 
        
        //suma de los clientes del cliente mas rico al menos.
        for (int i = 0; i < cuentas.length; i++) { 
            int suma = 0; 
            
            for (int j = 0; j < cuentas[i].length; j++) { 
                suma += cuentas[i][j]; 
            }
            
            if (suma > max) { 
                max = suma; 
            }
        }
       
        return max; 
    }
    
    public static void main(String[] args) {
        int[][] cuentas1 = {{1, 2, 3}, {3, 2, 1}};
        int[][] cuentas2 = {{1, 5}, {7, 3}, {3, 5}};
        int[][] cuentas3 = {{2, 8, 7}, {7, 1, 3}, {1, 9, 5}};
       
        System.out.println(encontrarRiquezaMaxima(cuentas1)); 
        System.out.println(encontrarRiquezaMaxima(cuentas2)); 
        System.out.println(encontrarRiquezaMaxima(cuentas3)); 
      
    }
    
}
