
package arreglos;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;


public class arrelgos2 {
    public static int[][] diagonales(int[][] mat) {
        int filas = mat.length;
        int columnas = mat[0].length;
        
       
        for (int j = 0; j < columnas; j++) {
            ordenar(mat, 0, j, filas, columnas);
        }
        
      
        for (int i = 1; i < filas; i++) {
            ordenar(mat, i, 0, filas, columnas);
        }
        
        return mat;
    }
    
    private static void ordenar(int[][] mat, int fila, int columna, int filas, int columnas) {
        List<Integer> diagonal = new ArrayList<>();
        int i = fila, j = columna;
        
       
        while (i < filas && j < columnas) {
            diagonal.add(mat[i][j]);
            i++;
            j++;
        }
        
       
        Collections.sort(diagonal);
        
      
        i = fila;
        j = columna;
        for (int num : diagonal) {
            mat[i][j] = num;
            i++;
            j++;
        }
    }
    
    public static void main(String[] args) {
        int[][] mat = {
            {3, 3, 1, 1},
            {2, 2, 1, 2},
            {1, 1, 1, 2}
        };
        
        mat = diagonales(mat);
        
        for (int[] fila : mat) {
            System.out.println(Arrays.toString(fila));
        }
    }
}

